-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 26, 2024 at 06:17 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `contacts`
--

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(6) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `middlename` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `country_code` varchar(10) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT current_timestamp(),
  `address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `user_id`, `firstname`, `middlename`, `lastname`, `email`, `country_code`, `phone`, `date_added`, `address`) VALUES
(16, 8, 'Achilles', 'Maraño', 'Panganiban', 'achillespanganiban@gmail.com', '+63', '9563258741', '2024-05-26 16:06:59', 'Palmera Springs 4, Camarin, Caloocan City'),
(17, 8, 'Reinmarc', '', 'Erasquin', 'reinmarcerasquin@gmail.com', '+63', '9658741254', '2024-05-26 16:07:57', 'Phase 7, Bagong Silang, Caloocan City'),
(18, 9, 'Achilles', 'Maraño', 'Panganiban', 'achillespanganiban@gmail.com', '+63', '9563258741', '2024-05-26 16:09:56', 'Palmera Springs 4, Camarin, Caloocan City'),
(19, 9, 'Reinmarc', '', 'Erasquin', 'reinmarcerasquin@gmail.com', '+63', '9658741254', '2024-05-26 16:10:32', 'Phase 7, Bagong Silang, Caloocan City');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `firstname` varchar(50) DEFAULT NULL,
  `lastname` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('user','admin') NOT NULL DEFAULT 'user',
  `status` enum('enabled','disabled') NOT NULL DEFAULT 'enabled'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `username`, `password`, `role`, `status`) VALUES
(2, 'Achilles', 'Panganiban', 'Maraño', 'admin', '$2y$10$6YHCnK0WW7Suh3nq0TSBF.Mm/8UUtwt9uGUdePziID0RidmWCSBzi', 'admin', 'enabled'),
(8, 'Achilles', 'Panganiban', 'achillespanganiban@gmail.com', 'aki', '$2y$10$HEqlnmskJARSNowjuiZdAu5QzbtshxF0tuuHEUq0dS9Ok198w6vmS', 'user', 'enabled'),
(9, 'Reinmarc', 'Erasquin', 'reinmarcerasquin@gmail.com', 'macmac', '$2y$10$N1V24sCJpOlptVr6iVxMpuos6BoNf6gFdHPceQeo2F6yib3zWxiE2', 'user', 'enabled');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`),
  ADD KEY `fk_user` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `contacts`
--
ALTER TABLE `contacts`
  ADD CONSTRAINT `fk_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
