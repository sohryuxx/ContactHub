<?php
session_start();
if (!isset($_SESSION['username'])) {
    echo "Unauthorized";
    exit;
}

if (isset($_POST['id'])) {
    require_once("connection.php");
    $user_id = $_POST['id'];

    mysqli_begin_transaction($conn);

    try {
        // Deletes contact/s associated with the user
        $deleteContactsQuery = "DELETE FROM contacts WHERE user_id = ?";
        $stmt = $conn->prepare($deleteContactsQuery);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->close();

        // Deletes the user
        $deleteUserQuery = "DELETE FROM users WHERE id = ?";
        $stmt = $conn->prepare($deleteUserQuery);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->close();

        mysqli_commit($conn);

        echo "success";
    } catch (Exception $e) {
        mysqli_rollback($conn);

        echo "failure";
    }
} else {
    echo "Invalid request";
}
?>
