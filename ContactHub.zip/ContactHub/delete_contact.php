<?php
session_start();

require_once("connection.php");

if (!isset($_SESSION['user_id'])) {
    echo "Session expired";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $contact_id = intval($_POST['id']);
    $user_id = intval($_SESSION['user_id']);

    $query = "DELETE FROM contacts WHERE id = ? AND user_id = ?";

    if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param("ii", $contact_id, $user_id);
        if ($stmt->execute()) {
            echo "success";
        } else {
            echo "error: " . htmlspecialchars($stmt->error);
        }
        $stmt->close();
    } else {
        echo "error: " . htmlspecialchars($conn->error);
    }

    $conn->close();
}
?>
