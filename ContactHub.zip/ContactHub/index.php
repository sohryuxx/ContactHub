<?php
session_start();

if (!isset($_SESSION['username'])) {
  header('Location: login.php');
  exit;
}

require_once("connection.php");
$userId = $_SESSION['user_id']; // Get the logged-in user's ID

// Fetch the first name of the logged-in user securely
$stmt = $conn->prepare("SELECT firstname FROM users WHERE id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$userData = $result->fetch_assoc();
$firstName = $userData['firstname'] ?? 'User';
$stmt->close();

// Fetch contacts securely
$stmt = $conn->prepare("SELECT * FROM contacts WHERE user_id = ? ORDER BY id DESC");
$stmt->bind_param("i", $userId);
$stmt->execute();
$query = $stmt->get_result();
$total_records = $query->num_rows;
$stmt->close();
?>



<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Contact Hub</title>
  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- IonIcons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="plugins/datatables-buttons/css/buttons.bootstrap4.min.css">

  <style>
    .length-buttons-container .dt-buttons {
    margin-left: 10px;
    }

    .rotate-icon {
      transition: transform 0.3s ease;
    }

    .rotate-icon.rotate {
      transform: rotate(-90deg);
    }

    .rotate-icon.reset {
      transform: rotate(0deg);
    }

    .card-header {
      cursor: pointer;
      background-color: #28a745;
      color: white;
    }

    .card-header h2 {
      margin: 0;
      width: 100%;
    }

    .modal-header .close {
      margin: -1rem -1rem -1rem auto;
    }

    .modal-header h4 {
      margin: 0;
    }

    .input-group .form-control[name="country_code"] {
        flex: 0 0 25%;
        max-width: 25%;
    }
    .input-group .form-control[name="phone"] {
        flex: 0 0 75%;
        max-width: 75%;
    }
  </style>
</head>

<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
    </ul>
    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <li class="nav-item">
        <a href="logout.php" onclick="return confirmLogout()" class="nav-link">
          <i class="nav-icon fas fa-sign-out-alt"></i>
          <span>Logout</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" data-widget="fullscreen" href="#" role="button">
          <i class="fas fa-expand-arrows-alt"></i>
        </a>
      </li>
    </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="index.php" class="brand-link">
      <img src="dist/img/ContactHubLogo.png" alt="ContactHub Logo" class="brand-image" style="opacity: .8">
      <span class="brand-text font-weight-light">ContactHub</span>
    </a>
    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar Menu -->
      <nav class="mt-2 nav-sidebar">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <li class="nav-item menu-open">
            <a href="#" class="nav-link active">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
                  <li class="nav-item">
                    <a href="index.php" class="nav-link active">
                      <i class="far fa-circle nav-icon"></i>
                      <p>Contacts</p>
                    </a>
                  </li>
                </ul>
          </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <div class="content mt-3">
      <div class="container-fluid">
        <!-- Greeting -->
        <div class="row">
          <div class="col-12"">
            <h3 class="mb-4 mt-3 ml-2" style="font-size: 35px;">Hi, <?php echo htmlspecialchars($firstName); ?>!</h3>
          </div>
        </div>
        <!-- /.greeting -->

        <div class="accordion" id="contactsAccordion">
          <div class="card">
            <div class="card-header" id="headingOne">
              <h2 class="mb-0 d-flex justify-content-between align-items-center" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                <button class="btn btn-link" style="font-size: 23px; text-align: left; padding-left: 0; color: white;">
                  Total Contacts: <?php echo $total_records; ?>
                </button>
                <span class="fas fa-angle-left rotate-icon reset"></span>
              </h2>
            </div>
            <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#contactsAccordion">
              <div class="card-body">
                <button class="btn btn-success btn-md mb-2" data-toggle="modal" data-target="#addContactModal">+ Add Contact</button>
                <table id="mainoutput" class="table table-bordered table-striped">
                  <thead>
                    <tr>
                      <th>First Name</th>
                      <th>Middle Name</th>
                      <th>Last Name</th>
                      <th>Email Address</th>
                      <th>Phone Number</th>
                      <th>Date Added</th>
                      <th>Address</th>
                      <th>Tasks</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php while ($row = mysqli_fetch_array($query)) { ?>
                    <tr>
                      <td><?php echo htmlspecialchars($row['firstname'] ?? ''); ?></td>
                      <td><?php echo htmlspecialchars($row['middlename'] ?? ''); ?></td>
                      <td><?php echo htmlspecialchars($row['lastname'] ?? ''); ?></td>
                      <td><?php echo htmlspecialchars($row['email'] ?? ''); ?></td>
                      <td><?php echo htmlspecialchars(($row['country_code'] ?? '') . ($row['phone'] ?? '')); ?></td>
                      <td><?php echo htmlspecialchars($row['date_added'] ?? ''); ?></td>
                      <td><?php echo htmlspecialchars($row['address'] ?? ''); ?></td>
                      <td style="font-size: 10px">
                        <button class="btn btn-primary btn-xs mb-1" data-toggle="modal" data-target="#editContactModal<?php echo $row['id']; ?>">EDIT</button>
                        <button class="btn btn-danger btn-xs delete" data-id="<?php echo $row['id']; ?>">DELETE</button>
                      </td>
                    </tr>
                    <!-- Edit Modal -->
                    <div class="modal fade" id="editContactModal<?php echo $row['id']; ?>" role="dialog">
                      <div class="modal-dialog">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h4 class="modal-title">Edit Contact</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">&times;</button>
                          </div>
                          <div class="modal-body">
                            <form class="editContactForm">
                              <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                              <div class="form-group">
                                <label for="firstname">First Name:</label>
                                <input type="text" class="form-control" name="firstname" value="<?php echo htmlspecialchars($row['firstname']); ?>" required>
                              </div>
                              <div class="form-group">
                                <label for="middlename">Middle Name:</label>
                                <input type="text" class="form-control" name="middlename" value="<?php echo htmlspecialchars($row['middlename']); ?>">
                              </div>
                              <div class="form-group">
                                <label for="lastname">Last Name:</label>
                                <input type="text" class="form-control" name="lastname" value="<?php echo htmlspecialchars($row['lastname']); ?>" required>
                              </div>
                              <div class="form-group">
                                <label for="email">Email:</label>
                                <input type="email" class="form-control" name="email" value="<?php echo htmlspecialchars($row['email']); ?>" required>
                              </div>
                              <div class="form-group">
                                <label for="phone">Phone Number:</label>
                                <div class="input-group">
                                  <select class="form-control" name="country_code" required>
                                  <option value="+93" <?php if ($row['country_code'] == '+93') echo 'selected'; ?>>+93 (Afghanistan)</option>
                                  <option value="+355" <?php if ($row['country_code'] == '+355') echo 'selected'; ?>>+355 (Albania)</option>
                                  <option value="+213" <?php if ($row['country_code'] == '+213') echo 'selected'; ?>>+213 (Algeria)</option>
                                  <option value="+1684" <?php if ($row['country_code'] == '+1684') echo 'selected'; ?>>+1684 (American Samoa)</option>
                                  <option value="+376" <?php if ($row['country_code'] == '+376') echo 'selected'; ?>>+376 (Andorra)</option>
                                  <option value="+244" <?php if ($row['country_code'] == '+244') echo 'selected'; ?>>+244 (Angola)</option>
                                  <option value="+1264" <?php if ($row['country_code'] == '+1264') echo 'selected'; ?>>+1264 (Anguilla)</option>
                                  <option value="+672" <?php if ($row['country_code'] == '+672') echo 'selected'; ?>>+672 (Antarctica)</option>
                                  <option value="+1268" <?php if ($row['country_code'] == '+1268') echo 'selected'; ?>>+1268 (Antigua and Barbuda)</option>
                                  <option value="+54" <?php if ($row['country_code'] == '+54') echo 'selected'; ?>>+54 (Argentina)</option>
                                  <option value="+374" <?php if ($row['country_code'] == '+374') echo 'selected'; ?>>+374 (Armenia)</option>
                                  <option value="+297" <?php if ($row['country_code'] == '+297') echo 'selected'; ?>>+297 (Aruba)</option>
                                  <option value="+61" <?php if ($row['country_code'] == '+61') echo 'selected'; ?>>+61 (Australia)</option>
                                  <option value="+43" <?php if ($row['country_code'] == '+43') echo 'selected'; ?>>+43 (Austria)</option>
                                  <option value="+994" <?php if ($row['country_code'] == '+994') echo 'selected'; ?>>+994 (Azerbaijan)</option>
                                  <option value="+973" <?php if ($row['country_code'] == '+973') echo 'selected'; ?>>+973 (Bahrain)</option>
                                  <option value="+880" <?php if ($row['country_code'] == '+880') echo 'selected'; ?>>+880 (Bangladesh)</option>
                                  <option value="+1246" <?php if ($row['country_code'] == '+1246') echo 'selected'; ?>>+1246 (Barbados)</option>
                                  <option value="+375" <?php if ($row['country_code'] == '+375') echo 'selected'; ?>>+375 (Belarus)</option>
                                  <option value="+32" <?php if ($row['country_code'] == '+32') echo 'selected'; ?>>+32 (Belgium)</option>
                                  <option value="+501" <?php if ($row['country_code'] == '+501') echo 'selected'; ?>>+501 (Belize)</option>
                                  <option value="+229" <?php if ($row['country_code'] == '+229') echo 'selected'; ?>>+229 (Benin)</option>
                                  <option value="+1441" <?php if ($row['country_code'] == '+1441') echo 'selected'; ?>>+1441 (Bermuda)</option>
                                  <option value="+975" <?php if ($row['country_code'] == '+975') echo 'selected'; ?>>+975 (Bhutan)</option>
                                  <option value="+591" <?php if ($row['country_code'] == '+591') echo 'selected'; ?>>+591 (Bolivia)</option>
                                  <option value="+387" <?php if ($row['country_code'] == '+387') echo 'selected'; ?>>+387 (Bosnia and Herzegovina)</option>
                                  <option value="+267" <?php if ($row['country_code'] == '+267') echo 'selected'; ?>>+267 (Botswana)</option>
                                  <option value="+55" <?php if ($row['country_code'] == '+55') echo 'selected'; ?>>+55 (Brazil)</option>
                                  <option value="+246" <?php if ($row['country_code'] == '+246') echo 'selected'; ?>>+246 (British Indian Ocean Territory)</option>
                                  <option value="+1284" <?php if ($row['country_code'] == '+1284') echo 'selected'; ?>>+1284 (British Virgin Islands)</option>
                                  <option value="+673" <?php if ($row['country_code'] == '+673') echo 'selected'; ?>>+673 (Brunei)</option>
                                  <option value="+359" <?php if ($row['country_code'] == '+359') echo 'selected'; ?>>+359 (Bulgaria)</option>
                                  <option value="+226" <?php if ($row['country_code'] == '+226') echo 'selected'; ?>>+226 (Burkina Faso)</option>
                                  <option value="+257" <?php if ($row['country_code'] == '+257') echo 'selected'; ?>>+257 (Burundi)</option>
                                  <option value="+855" <?php if ($row['country_code'] == '+855') echo 'selected'; ?>>+855 (Cambodia)</option>
                                  <option value="+237" <?php if ($row['country_code'] == '+237') echo 'selected'; ?>>+237 (Cameroon)</option>
                                  <option value="+1" <?php if ($row['country_code'] == '+1') echo 'selected'; ?>>+1 (Canada)</option>
                                  <option value="+238" <?php if ($row['country_code'] == '+238') echo 'selected'; ?>>+238 (Cape Verde)</option>
                                  <option value="+1345" <?php if ($row['country_code'] == '+1345') echo 'selected'; ?>>+1345 (Cayman Islands)</option>
                                  <option value="+236" <?php if ($row['country_code'] == '+236') echo 'selected'; ?>>+236 (Central African Republic)</option>
                                  <option value="+235" <?php if ($row['country_code'] == '+235') echo 'selected'; ?>>+235 (Chad)</option>
                                  <option value="+56" <?php if ($row['country_code'] == '+56') echo 'selected'; ?>>+56 (Chile)</option>
                                  <option value="+86" <?php if ($row['country_code'] == '+86') echo 'selected'; ?>>+86 (China)</option>
                                  <option value="+61" <?php if ($row['country_code'] == '+61') echo 'selected'; ?>>+61 (Christmas Island)</option>
                                  <option value="+61" <?php if ($row['country_code'] == '+61') echo 'selected'; ?>>+61 (Cocos Islands)</option>
                                  <option value="+57" <?php if ($row['country_code'] == '+57') echo 'selected'; ?>>+57 (Colombia)</option>
                                  <option value="+269" <?php if ($row['country_code'] == '+269') echo 'selected'; ?>>+269 (Comoros)</option>
                                  <option value="+682" <?php if ($row['country_code'] == '+682') echo 'selected'; ?>>+682 (Cook Islands)</option>
                                  <option value="+506" <?php if ($row['country_code'] == '+506') echo 'selected'; ?>>+506 (Costa Rica)</option>
                                  <option value="+385" <?php if ($row['country_code'] == '+385') echo 'selected'; ?>>+385 (Croatia)</option>
                                  <option value="+53" <?php if ($row['country_code'] == '+53') echo 'selected'; ?>>+53 (Cuba)</option>
                                  <option value="+599" <?php if ($row['country_code'] == '+599') echo 'selected'; ?>>+599 (Curacao)</option>
                                  <option value="+357" <?php if ($row['country_code'] == '+357') echo 'selected'; ?>>+357 (Cyprus)</option>
                                  <option value="+420" <?php if ($row['country_code'] == '+420') echo 'selected'; ?>>+420 (Czech Republic)</option>
                                  <option value="+243" <?php if ($row['country_code'] == '+243') echo 'selected'; ?>>+243 (Democratic Republic of the Congo)</option>
                                  <option value="+45" <?php if ($row['country_code'] == '+45') echo 'selected'; ?>>+45 (Denmark)</option>
                                  <option value="+253" <?php if ($row['country_code'] == '+253') echo 'selected'; ?>>+253 (Djibouti)</option>
                                  <option value="+1767" <?php if ($row['country_code'] == '+1767') echo 'selected'; ?>>+1767 (Dominica)</option>
                                  <option value="+1809" <?php if ($row['country_code'] == '+1809') echo 'selected'; ?>>+1809 (Dominican Republic)</option>
                                  <option value="+670" <?php if ($row['country_code'] == '+670') echo 'selected'; ?>>+670 (East Timor)</option>
                                  <option value="+593" <?php if ($row['country_code'] == '+593') echo 'selected'; ?>>+593 (Ecuador)</option>
                                  <option value="+20" <?php if ($row['country_code'] == '+20') echo 'selected'; ?>>+20 (Egypt)</option>
                                  <option value="+503" <?php if ($row['country_code'] == '+503') echo 'selected'; ?>>+503 (El Salvador)</option>
                                  <option value="+240" <?php if ($row['country_code'] == '+240') echo 'selected'; ?>>+240 (Equatorial Guinea)</option>
                                  <option value="+291" <?php if ($row['country_code'] == '+291') echo 'selected'; ?>>+291 (Eritrea)</option>
                                  <option value="+372" <?php if ($row['country_code'] == '+372') echo 'selected'; ?>>+372 (Estonia)</option>
                                  <option value="+251" <?php if ($row['country_code'] == '+251') echo 'selected'; ?>>+251 (Ethiopia)</option>
                                  <option value="+500" <?php if ($row['country_code'] == '+500') echo 'selected'; ?>>+500 (Falkland Islands)</option>
                                  <option value="+298" <?php if ($row['country_code'] == '+298') echo 'selected'; ?>>+298 (Faroe Islands)</option>
                                  <option value="+679" <?php if ($row['country_code'] == '+679') echo 'selected'; ?>>+679 (Fiji)</option>
                                  <option value="+358" <?php if ($row['country_code'] == '+358') echo 'selected'; ?>>+358 (Finland)</option>
                                  <option value="+33" <?php if ($row['country_code'] == '+33') echo 'selected'; ?>>+33 (France)</option>
                                  <option value="+594" <?php if ($row['country_code'] == '+594') echo 'selected'; ?>>+594 (French Guiana)</option>
                                  <option value="+689" <?php if ($row['country_code'] == '+689') echo 'selected'; ?>>+689 (French Polynesia)</option>
                                  <option value="+241" <?php if ($row['country_code'] == '+241') echo 'selected'; ?>>+241 (Gabon)</option>
                                  <option value="+220" <?php if ($row['country_code'] == '+220') echo 'selected'; ?>>+220 (Gambia)</option>
                                  <option value="+995" <?php if ($row['country_code'] == '+995') echo 'selected'; ?>>+995 (Georgia)</option>
                                  <option value="+49" <?php if ($row['country_code'] == '+49') echo 'selected'; ?>>+49 (Germany)</option>
                                  <option value="+233" <?php if ($row['country_code'] == '+233') echo 'selected'; ?>>+233 (Ghana)</option>
                                  <option value="+350" <?php if ($row['country_code'] == '+350') echo 'selected'; ?>>+350 (Gibraltar)</option>
                                  <option value="+30" <?php if ($row['country_code'] == '+30') echo 'selected'; ?>>+30 (Greece)</option>
                                  <option value="+299" <?php if ($row['country_code'] == '+299') echo 'selected'; ?>>+299 (Greenland)</option>
                                  <option value="+1473" <?php if ($row['country_code'] == '+1473') echo 'selected'; ?>>+1473 (Grenada)</option>
                                  <option value="+590" <?php if ($row['country_code'] == '+590') echo 'selected'; ?>>+590 (Guadeloupe)</option>
                                  <option value="+1671" <?php if ($row['country_code'] == '+1671') echo 'selected'; ?>>+1671 (Guam)</option>
                                  <option value="+502" <?php if ($row['country_code'] == '+502') echo 'selected'; ?>>+502 (Guatemala)</option>
                                  <option value="+224" <?php if ($row['country_code'] == '+224') echo 'selected'; ?>>+224 (Guinea)</option>
                                  <option value="+245" <?php if ($row['country_code'] == '+245') echo 'selected'; ?>>+245 (Guinea-Bissau)</option>
                                  <option value="+592" <?php if ($row['country_code'] == '+592') echo 'selected'; ?>>+592 (Guyana)</option>
                                  <option value="+509" <?php if ($row['country_code'] == '+509') echo 'selected'; ?>>+509 (Haiti)</option>
                                  <option value="+504" <?php if ($row['country_code'] == '+504') echo 'selected'; ?>>+504 (Honduras)</option>
                                  <option value="+852" <?php if ($row['country_code'] == '+852') echo 'selected'; ?>>+852 (Hong Kong)</option>
                                  <option value="+36" <?php if ($row['country_code'] == '+36') echo 'selected'; ?>>+36 (Hungary)</option>
                                  <option value="+354" <?php if ($row['country_code'] == '+354') echo 'selected'; ?>>+354 (Iceland)</option>
                                  <option value="+91" <?php if ($row['country_code'] == '+91') echo 'selected'; ?>>+91 (India)</option>
                                  <option value="+62" <?php if ($row['country_code'] == '+62') echo 'selected'; ?>>+62 (Indonesia)</option>
                                  <option value="+98" <?php if ($row['country_code'] == '+98') echo 'selected'; ?>>+98 (Iran)</option>
                                  <option value="+964" <?php if ($row['country_code'] == '+964') echo 'selected'; ?>>+964 (Iraq)</option>
                                  <option value="+353" <?php if ($row['country_code'] == '+353') echo 'selected'; ?>>+353 (Ireland)</option>
                                  <option value="+972" <?php if ($row['country_code'] == '+972') echo 'selected'; ?>>+972 (Israel)</option>
                                  <option value="+39" <?php if ($row['country_code'] == '+39') echo 'selected'; ?>>+39 (Italy)</option>
                                  <option value="+225" <?php if ($row['country_code'] == '+225') echo 'selected'; ?>>+225 (Ivory Coast)</option>
                                  <option value="+1876" <?php if ($row['country_code'] == '+1876') echo 'selected'; ?>>+1876 (Jamaica)</option>
                                  <option value="+81" <?php if ($row['country_code'] == '+81') echo 'selected'; ?>>+81 (Japan)</option>
                                  <option value="+962" <?php if ($row['country_code'] == '+962') echo 'selected'; ?>>+962 (Jordan)</option>
                                  <option value="+7" <?php if ($row['country_code'] == '+7') echo 'selected'; ?>>+7 (Kazakhstan)</option>
                                  <option value="+254" <?php if ($row['country_code'] == '+254') echo 'selected'; ?>>+254 (Kenya)</option>
                                  <option value="+686" <?php if ($row['country_code'] == '+686') echo 'selected'; ?>>+686 (Kiribati)</option>
                                  <option value="+383" <?php if ($row['country_code'] == '+383') echo 'selected'; ?>>+383 (Kosovo)</option>
                                  <option value="+965" <?php if ($row['country_code'] == '+965') echo 'selected'; ?>>+965 (Kuwait)</option>
                                  <option value="+996" <?php if ($row['country_code'] == '+996') echo 'selected'; ?>>+996 (Kyrgyzstan)</option>
                                  <option value="+856" <?php if ($row['country_code'] == '+856') echo 'selected'; ?>>+856 (Laos)</option>
                                  <option value="+371" <?php if ($row['country_code'] == '+371') echo 'selected'; ?>>+371 (Latvia)</option>
                                  <option value="+961" <?php if ($row['country_code'] == '+961') echo 'selected'; ?>>+961 (Lebanon)</option>
                                  <option value="+266" <?php if ($row['country_code'] == '+266') echo 'selected'; ?>>+266 (Lesotho)</option>
                                  <option value="+231" <?php if ($row['country_code'] == '+231') echo 'selected'; ?>>+231 (Liberia)</option>
                                  <option value="+218" <?php if ($row['country_code'] == '+218') echo 'selected'; ?>>+218 (Libya)</option>
                                  <option value="+423" <?php if ($row['country_code'] == '+423') echo 'selected'; ?>>+423 (Liechtenstein)</option>
                                  <option value="+370" <?php if ($row['country_code'] == '+370') echo 'selected'; ?>>+370 (Lithuania)</option>
                                  <option value="+352" <?php if ($row['country_code'] == '+352') echo 'selected'; ?>>+352 (Luxembourg)</option>
                                  <option value="+853" <?php if ($row['country_code'] == '+853') echo 'selected'; ?>>+853 (Macau)</option>
                                  <option value="+389" <?php if ($row['country_code'] == '+389') echo 'selected'; ?>>+389 (Macedonia)</option>
                                  <option value="+261" <?php if ($row['country_code'] == '+261') echo 'selected'; ?>>+261 (Madagascar)</option>
                                  <option value="+265" <?php if ($row['country_code'] == '+265') echo 'selected'; ?>>+265 (Malawi)</option>
                                  <option value="+60" <?php if ($row['country_code'] == '+60') echo 'selected'; ?>>+60 (Malaysia)</option>
                                  <option value="+960" <?php if ($row['country_code'] == '+960') echo 'selected'; ?>>+960 (Maldives)</option>
                                  <option value="+223" <?php if ($row['country_code'] == '+223') echo 'selected'; ?>>+223 (Mali)</option>
                                  <option value="+356" <?php if ($row['country_code'] == '+356') echo 'selected'; ?>>+356 (Malta)</option>
                                  <option value="+692" <?php if ($row['country_code'] == '+692') echo 'selected'; ?>>+692 (Marshall Islands)</option>
                                  <option value="+596" <?php if ($row['country_code'] == '+596') echo 'selected'; ?>>+596 (Martinique)</option>
                                  <option value="+222" <?php if ($row['country_code'] == '+222') echo 'selected'; ?>>+222 (Mauritania)</option>
                                  <option value="+230" <?php if ($row['country_code'] == '+230') echo 'selected'; ?>>+230 (Mauritius)</option>
                                  <option value="+262" <?php if ($row['country_code'] == '+262') echo 'selected'; ?>>+262 (Mayotte)</option>
                                  <option value="+52" <?php if ($row['country_code'] == '+52') echo 'selected'; ?>>+52 (Mexico)</option>
                                  <option value="+691" <?php if ($row['country_code'] == '+691') echo 'selected'; ?>>+691 (Micronesia)</option>
                                  <option value="+373" <?php if ($row['country_code'] == '+373') echo 'selected'; ?>>+373 (Moldova)</option>
                                  <option value="+377" <?php if ($row['country_code'] == '+377') echo 'selected'; ?>>+377 (Monaco)</option>
                                  <option value="+976" <?php if ($row['country_code'] == '+976') echo 'selected'; ?>>+976 (Mongolia)</option>
                                  <option value="+382" <?php if ($row['country_code'] == '+382') echo 'selected'; ?>>+382 (Montenegro)</option>
                                  <option value="+1664" <?php if ($row['country_code'] == '+1664') echo 'selected'; ?>>+1664 (Montserrat)</option>
                                  <option value="+212" <?php if ($row['country_code'] == '+212') echo 'selected'; ?>>+212 (Morocco)</option>
                                  <option value="+258" <?php if ($row['country_code'] == '+258') echo 'selected'; ?>>+258 (Mozambique)</option>
                                  <option value="+95" <?php if ($row['country_code'] == '+95') echo 'selected'; ?>>+95 (Myanmar)</option>
                                  <option value="+264" <?php if ($row['country_code'] == '+264') echo 'selected'; ?>>+264 (Namibia)</option>
                                  <option value="+674" <?php if ($row['country_code'] == '+674') echo 'selected'; ?>>+674 (Nauru)</option>
                                  <option value="+977" <?php if ($row['country_code'] == '+977') echo 'selected'; ?>>+977 (Nepal)</option>
                                  <option value="+31" <?php if ($row['country_code'] == '+31') echo 'selected'; ?>>+31 (Netherlands)</option>
                                  <option value="+599" <?php if ($row['country_code'] == '+599') echo 'selected'; ?>>+599 (Netherlands Antilles)</option>
                                  <option value="+687" <?php if ($row['country_code'] == '+687') echo 'selected'; ?>>+687 (New Caledonia)</option>
                                  <option value="+64" <?php if ($row['country_code'] == '+64') echo 'selected'; ?>>+64 (New Zealand)</option>
                                  <option value="+505" <?php if ($row['country_code'] == '+505') echo 'selected'; ?>>+505 (Nicaragua)</option>
                                  <option value="+227" <?php if ($row['country_code'] == '+227') echo 'selected'; ?>>+227 (Niger)</option>
                                  <option value="+234" <?php if ($row['country_code'] == '+234') echo 'selected'; ?>>+234 (Nigeria)</option>
                                  <option value="+683" <?php if ($row['country_code'] == '+683') echo 'selected'; ?>>+683 (Niue)</option>
                                  <option value="+850" <?php if ($row['country_code'] == '+850') echo 'selected'; ?>>+850 (North Korea)</option>
                                  <option value="+1670" <?php if ($row['country_code'] == '+1670') echo 'selected'; ?>>+1670 (Northern Mariana Islands)</option>
                                  <option value="+47" <?php if ($row['country_code'] == '+47') echo 'selected'; ?>>+47 (Norway)</option>
                                  <option value="+968" <?php if ($row['country_code'] == '+968') echo 'selected'; ?>>+968 (Oman)</option>
                                  <option value="+92" <?php if ($row['country_code'] == '+92') echo 'selected'; ?>>+92 (Pakistan)</option>
                                  <option value="+680" <?php if ($row['country_code'] == '+680') echo 'selected'; ?>>+680 (Palau)</option>
                                  <option value="+970" <?php if ($row['country_code'] == '+970') echo 'selected'; ?>>+970 (Palestinian Territory)</option>
                                  <option value="+507" <?php if ($row['country_code'] == '+507') echo 'selected'; ?>>+507 (Panama)</option>
                                  <option value="+675" <?php if ($row['country_code'] == '+675') echo 'selected'; ?>>+675 (Papua New Guinea)</option>
                                  <option value="+595" <?php if ($row['country_code'] == '+595') echo 'selected'; ?>>+595 (Paraguay)</option>
                                  <option value="+51" <?php if ($row['country_code'] == '+51') echo 'selected'; ?>>+51 (Peru)</option>
                                  <option value="+63" <?php if ($row['country_code'] == '+63') echo 'selected'; ?>>+63 (Philippines)</option>
                                  <option value="+64" <?php if ($row['country_code'] == '+64') echo 'selected'; ?>>+64 (Pitcairn)</option>
                                  <option value="+48" <?php if ($row['country_code'] == '+48') echo 'selected'; ?>>+48 (Poland)</option>
                                  <option value="+351" <?php if ($row['country_code'] == '+351') echo 'selected'; ?>>+351 (Portugal)</option>
                                  <option value="+1787" <?php if ($row['country_code'] == '+1787') echo 'selected'; ?>>+1787 (Puerto Rico)</option>
                                  <option value="+974" <?php if ($row['country_code'] == '+974') echo 'selected'; ?>>+974 (Qatar)</option>
                                  <option value="+242" <?php if ($row['country_code'] == '+242') echo 'selected'; ?>>+242 (Republic of the Congo)</option>
                                  <option value="+40" <?php if ($row['country_code'] == '+40') echo 'selected'; ?>>+40 (Romania)</option>
                                  <option value="+7" <?php if ($row['country_code'] == '+7') echo 'selected'; ?>>+7 (Russia)</option>
                                  <option value="+250" <?php if ($row['country_code'] == '+250') echo 'selected'; ?>>+250 (Rwanda)</option>
                                  <option value="+590" <?php if ($row['country_code'] == '+590') echo 'selected'; ?>>+590 (Saint Barthelemy)</option>
                                  <option value="+290" <?php if ($row['country_code'] == '+290') echo 'selected'; ?>>+290 (Saint Helena)</option>
                                  <option value="+1869" <?php if ($row['country_code'] == '+1869') echo 'selected'; ?>>+1869 (Saint Kitts and Nevis)</option>
                                  <option value="+1758" <?php if ($row['country_code'] == '+1758') echo 'selected'; ?>>+1758 (Saint Lucia)</option>
                                  <option value="+590" <?php if ($row['country_code'] == '+590') echo 'selected'; ?>>+590 (Saint Martin)</option>
                                  <option value="+508" <?php if ($row['country_code'] == '+508') echo 'selected'; ?>>+508 (Saint Pierre and Miquelon)</option>
                                  <option value="+1784" <?php if ($row['country_code'] == '+1784') echo 'selected'; ?>>+1784 (Saint Vincent and the Grenadines)</option>
                                  <option value="+685" <?php if ($row['country_code'] == '+685') echo 'selected'; ?>>+685 (Samoa)</option>
                                  <option value="+378" <?php if ($row['country_code'] == '+378') echo 'selected'; ?>>+378 (San Marino)</option>
                                  <option value="+239" <?php if ($row['country_code'] == '+239') echo 'selected'; ?>>+239 (Sao Tome and Principe)</option>
                                  <option value="+966" <?php if ($row['country_code'] == '+966') echo 'selected'; ?>>+966 (Saudi Arabia)</option>
                                  <option value="+221" <?php if ($row['country_code'] == '+221') echo 'selected'; ?>>+221 (Senegal)</option>
                                  <option value="+381" <?php if ($row['country_code'] == '+381') echo 'selected'; ?>>+381 (Serbia)</option>
                                  <option value="+248" <?php if ($row['country_code'] == '+248') echo 'selected'; ?>>+248 (Seychelles)</option>
                                  <option value="+232" <?php if ($row['country_code'] == '+232') echo 'selected'; ?>>+232 (Sierra Leone)</option>
                                  <option value="+65" <?php if ($row['country_code'] == '+65') echo 'selected'; ?>>+65 (Singapore)</option>
                                  <option value="+421" <?php if ($row['country_code'] == '+421') echo 'selected'; ?>>+421 (Slovakia)</option>
                                  <option value="+386" <?php if ($row['country_code'] == '+386') echo 'selected'; ?>>+386 (Slovenia)</option>
                                  <option value="+677" <?php if ($row['country_code'] == '+677') echo 'selected'; ?>>+677 (Solomon Islands)</option>
                                  <option value="+252" <?php if ($row['country_code'] == '+252') echo 'selected'; ?>>+252 (Somalia)</option>
                                  <option value="+27" <?php if ($row['country_code'] == '+27') echo 'selected'; ?>>+27 (South Africa)</option>
                                  <option value="+82" <?php if ($row['country_code'] == '+82') echo 'selected'; ?>>+82 (South Korea)</option>
                                  <option value="+34" <?php if ($row['country_code'] == '+34') echo 'selected'; ?>>+34 (Spain)</option>
                                  <option value="+94" <?php if ($row['country_code'] == '+94') echo 'selected'; ?>>+94 (Sri Lanka)</option>
                                  <option value="+249" <?php if ($row['country_code'] == '+249') echo 'selected'; ?>>+249 (Sudan)</option>
                                  <option value="+597" <?php if ($row['country_code'] == '+597') echo 'selected'; ?>>+597 (Suriname)</option>
                                  <option value="+268" <?php if ($row['country_code'] == '+268') echo 'selected'; ?>>+268 (Swaziland)</option>
                                  <option value="+46" <?php if ($row['country_code'] == '+46') echo 'selected'; ?>>+46 (Sweden)</option>
                                  <option value="+41" <?php if ($row['country_code'] == '+41') echo 'selected'; ?>>+41 (Switzerland)</option>
                                  <option value="+963" <?php if ($row['country_code'] == '+963') echo 'selected'; ?>>+963 (Syria)</option>
                                  <option value="+886" <?php if ($row['country_code'] == '+886') echo 'selected'; ?>>+886 (Taiwan)</option>
                                  <option value="+992" <?php if ($row['country_code'] == '+992') echo 'selected'; ?>>+992 (Tajikistan)</option>
                                  <option value="+255" <?php if ($row['country_code'] == '+255') echo 'selected'; ?>>+255 (Tanzania)</option>
                                  <option value="+66" <?php if ($row['country_code'] == '+66') echo 'selected'; ?>>+66 (Thailand)</option>
                                  <option value="+228" <?php if ($row['country_code'] == '+228') echo 'selected'; ?>>+228 (Togo)</option>
                                  <option value="+690" <?php if ($row['country_code'] == '+690') echo 'selected'; ?>>+690 (Tokelau)</option>
                                  <option value="+676" <?php if ($row['country_code'] == '+676') echo 'selected'; ?>>+676 (Tonga)</option>
                                  <option value="+1868" <?php if ($row['country_code'] == '+1868') echo 'selected'; ?>>+1868 (Trinidad and Tobago)</option>
                                  <option value="+216" <?php if ($row['country_code'] == '+216') echo 'selected'; ?>>+216 (Tunisia)</option>
                                  <option value="+90" <?php if ($row['country_code'] == '+90') echo 'selected'; ?>>+90 (Turkey)</option>
                                  <option value="+993" <?php if ($row['country_code'] == '+993') echo 'selected'; ?>>+993 (Turkmenistan)</option>
                                  <option value="+1649" <?php if ($row['country_code'] == '+1649') echo 'selected'; ?>>+1649 (Turks and Caicos Islands)</option>
                                  <option value="+688" <?php if ($row['country_code'] == '+688') echo 'selected'; ?>>+688 (Tuvalu)</option>
                                  <option value="+256" <?php if ($row['country_code'] == '+256') echo 'selected'; ?>>+256 (Uganda)</option>
                                  <option value="+380" <?php if ($row['country_code'] == '+380') echo 'selected'; ?>>+380 (Ukraine)</option>
                                  <option value="+971" <?php if ($row['country_code'] == '+971') echo 'selected'; ?>>+971 (UAE)</option>
                                  <option value="+44" <?php if ($row['country_code'] == '+44') echo 'selected'; ?>>+44 (UK)</option>
                                  <option value="+1" <?php if ($row['country_code'] == '+1') echo 'selected'; ?>>+1 (USA)</option>
                                  <option value="+598" <?php if ($row['country_code'] == '+598') echo 'selected'; ?>>+598 (Uruguay)</option>
                                  <option value="+998" <?php if ($row['country_code'] == '+998') echo 'selected'; ?>>+998 (Uzbekistan)</option>
                                  <option value="+678" <?php if ($row['country_code'] == '+678') echo 'selected'; ?>>+678 (Vanuatu)</option>
                                  <option value="+58" <?php if ($row['country_code'] == '+58') echo 'selected'; ?>>+58 (Venezuela)</option>
                                  <option value="+84" <?php if ($row['country_code'] == '+84') echo 'selected'; ?>>+84 (Vietnam)</option>
                                  <option value="+1284" <?php if ($row['country_code'] == '+1284') echo 'selected'; ?>>+1284 (British Virgin Islands)</option>
                                  <option value="+1340" <?php if ($row['country_code'] == '+1340') echo 'selected'; ?>>+1340 (U.S. Virgin Islands)</option>
                                  <option value="+681" <?php if ($row['country_code'] == '+681') echo 'selected'; ?>>+681 (Wallis and Futuna)</option>
                                  <option value="+967" <?php if ($row['country_code'] == '+967') echo 'selected'; ?>>+967 (Yemen)</option>
                                  <option value="+260" <?php if ($row['country_code'] == '+260') echo 'selected'; ?>>+260 (Zambia)</option>
                                  <option value="+263" <?php if ($row['country_code'] == '+263') echo 'selected'; ?>>+263 (Zimbabwe)</option>
                                  </select>
                                  <input type="text" class="form-control" name="phone" value="<?php echo htmlspecialchars($row['phone'] ?? ''); ?>" placeholder="Enter Phone Number" required pattern="[0-9]{10,11}" maxlength="11" required>
                                </div>
                              </div>
                              <div class="form-group">
                                <label for="address">Address:</label>
                                <input type="text" class="form-control" name="address" value="<?php echo htmlspecialchars($row['address']); ?>" required>
                              </div>
                              <button type="submit" class="btn btn-primary">Save</button>
                            </form>
                          </div>
                        </div>
                      </div>
                    </div>
                    <!-- /.edit modal -->
                  <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        <!-- Add Contact Modal -->
        <div class="modal fade" id="addContactModal" role="dialog">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h4 class="modal-title">Add Contact</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">&times;</button>
              </div>
              <div class="modal-body">
                <form id="addContactForm">
                  <div class="form-group">
                    <label for="firstname">First Name:</label>
                    <input type="text" class="form-control" name="firstname" required>
                  </div>
                  <div class="form-group">
                    <label for="middlename">Middle Name:</label>
                    <input type="text" class="form-control" name="middlename">
                  </div>
                  <div class="form-group">
                    <label for="lastname">Last Name:</label>
                    <input type="text" class="form-control" name="lastname" required>
                  </div>
                  <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" class="form-control" name="email" required>
                  </div>
                  <div class="form-group">
                    <label for="phone">Phone Number:</label>
                    <div class="input-group">
                      <select class="form-control" name="country_code" required>
                      <option value="+93">+93 (Afghanistan)</option>
                      <option value="+355">+355 (Albania)</option>
                      <option value="+213">+213 (Algeria)</option>
                      <option value="+1684">+1684 (American Samoa)</option>
                      <option value="+376">+376 (Andorra)</option>
                      <option value="+244">+244 (Angola)</option>
                      <option value="+1264">+1264 (Anguilla)</option>
                      <option value="+672">+672 (Antarctica)</option>
                      <option value="+1268">+1268 (Antigua and Barbuda)</option>
                      <option value="+54">+54 (Argentina)</option>
                      <option value="+374">+374 (Armenia)</option>
                      <option value="+297">+297 (Aruba)</option>
                      <option value="+61">+61 (Australia)</option>
                      <option value="+43">+43 (Austria)</option>
                      <option value="+994">+994 (Azerbaijan)</option>
                      <option value="+1242">+1242 (Bahamas)</option>
                      <option value="+973">+973 (Bahrain)</option>
                      <option value="+880">+880 (Bangladesh)</option>
                      <option value="+1246">+1246 (Barbados)</option>
                      <option value="+375">+375 (Belarus)</option>
                      <option value="+32">+32 (Belgium)</option>
                      <option value="+501">+501 (Belize)</option>
                      <option value="+229">+229 (Benin)</option>
                      <option value="+1441">+1441 (Bermuda)</option>
                      <option value="+975">+975 (Bhutan)</option>
                      <option value="+591">+591 (Bolivia)</option>
                      <option value="+387">+387 (Bosnia and Herzegovina)</option>
                      <option value="+267">+267 (Botswana)</option>
                      <option value="+55">+55 (Brazil)</option>
                      <option value="+246">+246 (British Indian Ocean Territory)</option>
                      <option value="+1284">+1284 (British Virgin Islands)</option>
                      <option value="+673">+673 (Brunei)</option>
                      <option value="+359">+359 (Bulgaria)</option>
                      <option value="+226">+226 (Burkina Faso)</option>
                      <option value="+257">+257 (Burundi)</option>
                      <option value="+855">+855 (Cambodia)</option>
                      <option value="+237">+237 (Cameroon)</option>
                      <option value="+1">+1 (Canada)</option>
                      <option value="+238">+238 (Cape Verde)</option>
                      <option value="+1345">+1345 (Cayman Islands)</option>
                      <option value="+236">+236 (Central African Republic)</option>
                      <option value="+235">+235 (Chad)</option>
                      <option value="+56">+56 (Chile)</option>
                      <option value="+86">+86 (China)</option>
                      <option value="+61">+61 (Christmas Island)</option>
                      <option value="+61">+61 (Cocos Islands)</option>
                      <option value="+57">+57 (Colombia)</option>
                      <option value="+269">+269 (Comoros)</option>
                      <option value="+682">+682 (Cook Islands)</option>
                      <option value="+506">+506 (Costa Rica)</option>
                      <option value="+385">+385 (Croatia)</option>
                      <option value="+53">+53 (Cuba)</option>
                      <option value="+599">+599 (Curacao)</option>
                      <option value="+357">+357 (Cyprus)</option>
                      <option value="+420">+420 (Czech Republic)</option>
                      <option value="+243">+243 (Democratic Republic of the Congo)</option>
                      <option value="+45">+45 (Denmark)</option>
                      <option value="+253">+253 (Djibouti)</option>
                      <option value="+1767">+1767 (Dominica)</option>
                      <option value="+1809">+1809 (Dominican Republic)</option>
                      <option value="+670">+670 (East Timor)</option>
                      <option value="+593">+593 (Ecuador)</option>
                      <option value="+20">+20 (Egypt)</option>
                      <option value="+503">+503 (El Salvador)</option>
                      <option value="+240">+240 (Equatorial Guinea)</option>
                      <option value="+291">+291 (Eritrea)</option>
                      <option value="+372">+372 (Estonia)</option>
                      <option value="+251">+251 (Ethiopia)</option>
                      <option value="+500">+500 (Falkland Islands)</option>
                      <option value="+298">+298 (Faroe Islands)</option>
                      <option value="+679">+679 (Fiji)</option>
                      <option value="+358">+358 (Finland)</option>
                      <option value="+33">+33 (France)</option>
                      <option value="+594">+594 (French Guiana)</option>
                      <option value="+689">+689 (French Polynesia)</option>
                      <option value="+241">+241 (Gabon)</option>
                      <option value="+220">+220 (Gambia)</option>
                      <option value="+995">+995 (Georgia)</option>
                      <option value="+49">+49 (Germany)</option>
                      <option value="+233">+233 (Ghana)</option>
                      <option value="+350">+350 (Gibraltar)</option>
                      <option value="+30">+30 (Greece)</option>
                      <option value="+299">+299 (Greenland)</option>
                      <option value="+1473">+1473 (Grenada)</option>
                      <option value="+590">+590 (Guadeloupe)</option>
                      <option value="+1671">+1671 (Guam)</option>
                      <option value="+502">+502 (Guatemala)</option>
                      <option value="+224">+224 (Guinea)</option>
                      <option value="+245">+245 (Guinea-Bissau)</option>
                      <option value="+592">+592 (Guyana)</option>
                      <option value="+509">+509 (Haiti)</option>
                      <option value="+504">+504 (Honduras)</option>
                      <option value="+852">+852 (Hong Kong)</option>
                      <option value="+36">+36 (Hungary)</option>
                      <option value="+354">+354 (Iceland)</option>
                      <option value="+91">+91 (India)</option>
                      <option value="+62">+62 (Indonesia)</option>
                      <option value="+98">+98 (Iran)</option>
                      <option value="+964">+964 (Iraq)</option>
                      <option value="+353">+353 (Ireland)</option>
                      <option value="+972">+972 (Israel)</option>
                      <option value="+39">+39 (Italy)</option>
                      <option value="+225">+225 (Ivory Coast)</option>
                      <option value="+1876">+1876 (Jamaica)</option>
                      <option value="+81">+81 (Japan)</option>
                      <option value="+962">+962 (Jordan)</option>
                      <option value="+7">+7 (Kazakhstan)</option>
                      <option value="+254">+254 (Kenya)</option>
                      <option value="+686">+686 (Kiribati)</option>
                      <option value="+383">+383 (Kosovo)</option>
                      <option value="+965">+965 (Kuwait)</option>
                      <option value="+996">+996 (Kyrgyzstan)</option>
                      <option value="+856">+856 (Laos)</option>
                      <option value="+371">+371 (Latvia)</option>
                      <option value="+961">+961 (Lebanon)</option>
                      <option value="+266">+266 (Lesotho)</option>
                      <option value="+231">+231 (Liberia)</option>
                      <option value="+218">+218 (Libya)</option>
                      <option value="+423">+423 (Liechtenstein)</option>
                      <option value="+370">+370 (Lithuania)</option>
                      <option value="+352">+352 (Luxembourg)</option>
                      <option value="+853">+853 (Macau)</option>
                      <option value="+389">+389 (Macedonia)</option>
                      <option value="+261">+261 (Madagascar)</option>
                      <option value="+265">+265 (Malawi)</option>
                      <option value="+60">+60 (Malaysia)</option>
                      <option value="+960">+960 (Maldives)</option>
                      <option value="+223">+223 (Mali)</option>
                      <option value="+356">+356 (Malta)</option>
                      <option value="+692">+692 (Marshall Islands)</option>
                      <option value="+596">+596 (Martinique)</option>
                      <option value="+222">+222 (Mauritania)</option>
                      <option value="+230">+230 (Mauritius)</option>
                      <option value="+262">+262 (Mayotte)</option>
                      <option value="+52">+52 (Mexico)</option>
                      <option value="+691">+691 (Micronesia)</option>
                      <option value="+373">+373 (Moldova)</option>
                      <option value="+377">+377 (Monaco)</option>
                      <option value="+976">+976 (Mongolia)</option>
                      <option value="+382">+382 (Montenegro)</option>
                      <option value="+1664">+1664 (Montserrat)</option>
                      <option value="+212">+212 (Morocco)</option>
                      <option value="+258">+258 (Mozambique)</option>
                      <option value="+95">+95 (Myanmar)</option>
                      <option value="+264">+264 (Namibia)</option>
                      <option value="+674">+674 (Nauru)</option>
                      <option value="+977">+977 (Nepal)</option>
                      <option value="+31">+31 (Netherlands)</option>
                      <option value="+599">+599 (Netherlands Antilles)</option>
                      <option value="+687">+687 (New Caledonia)</option>
                      <option value="+64">+64 (New Zealand)</option>
                      <option value="+505">+505 (Nicaragua)</option>
                      <option value="+227">+227 (Niger)</option>
                      <option value="+234">+234 (Nigeria)</option>
                      <option value="+683">+683 (Niue)</option>
                      <option value="+850">+850 (North Korea)</option>
                      <option value="+1670">+1670 (Northern Mariana Islands)</option>
                      <option value="+47">+47 (Norway)</option>
                      <option value="+968">+968 (Oman)</option>
                      <option value="+92">+92 (Pakistan)</option>
                      <option value="+680">+680 (Palau)</option>
                      <option value="+970">+970 (Palestinian Territory)</option>
                      <option value="+507">+507 (Panama)</option>
                      <option value="+675">+675 (Papua New Guinea)</option>
                      <option value="+595">+595 (Paraguay)</option>
                      <option value="+51">+51 (Peru)</option>
                      <option value="+63">+63 (Philippines)</option>
                      <option value="+64">+64 (Pitcairn)</option>
                      <option value="+48">+48 (Poland)</option>
                      <option value="+351">+351 (Portugal)</option>
                      <option value="+1787">+1787 (Puerto Rico)</option>
                      <option value="+974">+974 (Qatar)</option>
                      <option value="+242">+242 (Republic of the Congo)</option>
                      <option value="+40">+40 (Romania)</option>
                      <option value="+7">+7 (Russia)</option>
                      <option value="+250">+250 (Rwanda)</option>
                      <option value="+590">+590 (Saint Barthelemy)</option>
                      <option value="+290">+290 (Saint Helena)</option>
                      <option value="+1869">+1869 (Saint Kitts and Nevis)</option>
                      <option value="+1758">+1758 (Saint Lucia)</option>
                      <option value="+590">+590 (Saint Martin)</option>
                      <option value="+508">+508 (Saint Pierre and Miquelon)</option>
                      <option value="+1784">+1784 (Saint Vincent and the Grenadines)</option>
                      <option value="+685">+685 (Samoa)</option>
                      <option value="+378">+378 (San Marino)</option>
                      <option value="+239">+239 (Sao Tome and Principe)</option>
                      <option value="+966">+966 (Saudi Arabia)</option>
                      <option value="+221">+221 (Senegal)</option>
                      <option value="+381">+381 (Serbia)</option>
                      <option value="+248">+248 (Seychelles)</option>
                      <option value="+232">+232 (Sierra Leone)</option>
                      <option value="+65">+65 (Singapore)</option>
                      <option value="+421">+421 (Slovakia)</option>
                      <option value="+386">+386 (Slovenia)</option>
                      <option value="+677">+677 (Solomon Islands)</option>
                      <option value="+252">+252 (Somalia)</option>
                      <option value="+27">+27 (South Africa)</option>
                      <option value="+82">+82 (South Korea)</option>
                      <option value="+34">+34 (Spain)</option>
                      <option value="+94">+94 (Sri Lanka)</option>
                      <option value="+249">+249 (Sudan)</option>
                      <option value="+597">+597 (Suriname)</option>
                      <option value="+268">+268 (Swaziland)</option>
                      <option value="+46">+46 (Sweden)</option>
                      <option value="+41">+41 (Switzerland)</option>
                      <option value="+963">+963 (Syria)</option>
                      <option value="+886">+886 (Taiwan)</option>
                      <option value="+992">+992 (Tajikistan)</option>
                      <option value="+255">+255 (Tanzania)</option>
                      <option value="+66">+66 (Thailand)</option>
                      <option value="+228">+228 (Togo)</option>
                      <option value="+690">+690 (Tokelau)</option>
                      <option value="+676">+676 (Tonga)</option>
                      <option value="+1868">+1868 (Trinidad and Tobago)</option>
                      <option value="+216">+216 (Tunisia)</option>
                      <option value="+90">+90 (Turkey)</option>
                      <option value="+993">+993 (Turkmenistan)</option>
                      <option value="+1649">+1649 (Turks and Caicos Islands)</option>
                      <option value="+688">+688 (Tuvalu)</option>
                      <option value="+256">+256 (Uganda)</option>
                      <option value="+380">+380 (Ukraine)</option>
                      <option value="+971">+971 (UAE)</option>
                      <option value="+44">+44 (UK)</option>
                      <option value="+1">+1 (US)</option>
                      <option value="+598">+598 (Uruguay)</option>
                      <option value="+998">+998 (Uzbekistan)</option>
                      <option value="+678">+678 (Vanuatu)</option>
                      <option value="+58">+58 (Venezuela)</option>
                      <option value="+84">+84 (Vietnam)</option>
                      <option value="+681">+681 (Wallis and Futuna)</option>
                      <option value="+967">+967 (Yemen)</option>
                      <option value="+260">+260 (Zambia)</option>
                      <option value="+263">+263 (Zimbabwe)</option>
                      </select>
                      <input type="text" class="form-control" name="phone" placeholder="Enter Phone Number" required pattern="[0-9]{10,11}" maxlength="11" required>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="address">Address:</label>
                    <input type="text" class="form-control" name="address" required>
                  </div>
                  <button type="submit" class="btn btn-primary">Add</button>
                </form>
              </div>
            </div>
          </div>
        </div>
        <!-- /.add contact modal -->

      </div>
    </div>
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
  </aside>
  <!-- /.control-sidebar -->

  <!-- Main Footer -->
  <footer class="main-footer">
    <strong>&copy; 2024 <a href="#">ContactHub</a>.</strong>
  </footer>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->
<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE -->
<script src="dist/js/adminlte.js"></script>

<!-- DataTables  & Plugins -->
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="plugins/jszip/jszip.min.js"></script>
<script src="plugins/pdfmake/pdfmake.min.js"></script>
<script src="plugins/pdfmake/vfs_fonts.js"></script>
<script src="plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.colVis.min.js"></script>

<script>
$(function () {
  $("#mainoutput").DataTable({
    "responsive": true,
    "lengthChange": true,
    "pageLength": 5,
    "autoWidth": false,
    "paging": true,
    "searching": true,
    "ordering": true,
    "info": true,
    "buttons": ["copy", "csv", "excel", "pdf", "print"],
    "language": {
      "searchPlaceholder": "Search contact details..."
    },
    "lengthMenu": [5, 10, 25, 50, 75, 100],
    "dom": '<"row"<"col-md-6 d-flex align-items-center length-buttons-container"lB><"col-md-6"f>>' + 
           '<"row"<"col-sm-12"tr>>' + 
           '<"row"<"col-sm-5"i><"col-sm-7"p>>'
  }).buttons().container().appendTo('#mainoutput_wrapper .col-md-6.length-buttons-container');
});

  $(document).ready(function() {
    $('#addContactForm').submit(function(e) {
        e.preventDefault();
        $.ajax({
            type: 'POST',
            url: 'add_contact.php',
            data: $(this).serialize(),
            success: function(response) {
                if (response.trim() === "success") {
                    alert("Contact added successfully.");
                    $('#addContactModal').modal('hide');
                    location.reload();
                } else {
                    alert("Failed to add contact: " + response);
                }
            }
        });
    });

    $('.editContactForm').submit(function(e) {
        e.preventDefault();
        $.ajax({
            type: 'POST',
            url: 'edit_contact.php',
            data: $(this).serialize(),
            success: function(response) {
                if (response.trim() === "success") {
                    alert("Contact updated successfully.");
                    $('.modal').modal('hide');
                    location.reload();
                } else {
                    alert("Failed to update contact: " + response);
                }
            }
        });
    });

    $('.delete').click(function() {
        if (confirm("Are you sure you want to delete this contact?")) {
            var id = $(this).data('id');
            $.ajax({
                type: 'POST',
                url: 'delete_contact.php',
                data: {id: id},
                success: function(response) {
                    if (response.trim() === "success") {
                        alert("Contact deleted successfully.");
                        location.reload();
                    } else {
                        alert("Failed to delete contact: " + response);
                    }
                }
            });
        }
     });
  });

  $(document).on('input', 'input[name="phone"]', function() {
    $(this).val($(this).val().replace(/\D/, ''));
  });

  $('#headingOne').click(function () {
    $('#collapseOne').collapse('toggle');
  });

  $('#contactsAccordion').on('show.bs.collapse', function () {
    $('#headingOne .rotate-icon').addClass('rotate').removeClass('reset');
  }).on('hide.bs.collapse', function () {
    $('#headingOne .rotate-icon').removeClass('rotate').addClass('reset');
  });

  function confirmLogout() {
    return confirm("Are you sure you want to logout?");
  }
</script>
</body>
</html>

