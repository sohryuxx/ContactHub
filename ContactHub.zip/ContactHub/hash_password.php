<?php
// Database connection
require_once("connection.php");

// Define the username and plain text password for the admin account
$username = 'admin_username';
$password = 'CMS_WEBDEV2';

$hashedPassword = password_hash($password, PASSWORD_BCRYPT);

$sql = "UPDATE users SET password = ? WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('ss', $hashedPassword, $username);

if ($stmt->execute()) {
    echo "Password hashed and updated successfully.";
} else {
    echo "Error updating password: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
