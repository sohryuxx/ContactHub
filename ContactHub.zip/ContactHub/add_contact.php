<?php
session_start();

require_once("connection.php");

if (!isset($_SESSION['user_id'])) {
    echo "Session expired";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = intval($_SESSION['user_id']);
    $firstname = mysqli_real_escape_string($conn, trim($_POST['firstname']));
    $middlename = mysqli_real_escape_string($conn, trim($_POST['middlename']));
    $lastname = mysqli_real_escape_string($conn, trim($_POST['lastname']));
    $email = mysqli_real_escape_string($conn, trim($_POST['email']));
    $country_code = mysqli_real_escape_string($conn, trim($_POST['country_code']));
    $phone = mysqli_real_escape_string($conn, trim($_POST['phone']));
    $address = mysqli_real_escape_string($conn, trim($_POST['address']));

    if (empty($firstname) || empty($lastname) || empty($email) || empty($phone) || empty($country_code)) {
        echo "All required fields must be filled.";
        exit;
    }

    // Check if the contact already exists
    $check_query = "SELECT * FROM contacts WHERE user_id = ? AND (email = ? OR (country_code = ? AND phone = ?))";
    if ($stmt = $conn->prepare($check_query)) {
        $stmt->bind_param("isss", $user_id, $email, $country_code, $phone);
        $stmt->execute();
        $stmt->store_result();
        
        if ($stmt->num_rows > 0) {
            echo "exists";
            $stmt->close();
            $conn->close();
            exit;
        }
        $stmt->close();
    } else {
        echo "Prepare failed: " . htmlspecialchars($conn->error);
        $conn->close();
        exit;
    }

    // Insert new contact
    $insert_query = "INSERT INTO contacts (firstname, middlename, lastname, email, phone, address, country_code, user_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    if ($stmt = $conn->prepare($insert_query)) {
        $stmt->bind_param("sssssssi", $firstname, $middlename, $lastname, $email, $phone, $address, $country_code, $user_id);

        if ($stmt->execute()) {
            echo "success";
        } else {
            echo "Execute failed: (" . $stmt->errno . ") " . htmlspecialchars($stmt->error);
        }
        $stmt->close();
    } else {
        echo "Prepare failed: " . htmlspecialchars($conn->error);
    }

    $conn->close();
}
?>
