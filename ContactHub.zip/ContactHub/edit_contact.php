<?php
session_start();

require_once("connection.php");

if (!isset($_SESSION['user_id'])) {
    echo "Session expired";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = intval($_POST['id']);
    $user_id = intval($_SESSION['user_id']);
    $firstname = mysqli_real_escape_string($conn, trim($_POST['firstname']));
    $middlename = mysqli_real_escape_string($conn, trim($_POST['middlename']));
    $lastname = mysqli_real_escape_string($conn, trim($_POST['lastname']));
    $email = mysqli_real_escape_string($conn, trim($_POST['email']));
    $country_code = mysqli_real_escape_string($conn, trim($_POST['country_code']));
    $phone = mysqli_real_escape_string($conn, trim($_POST['phone']));
    $address = mysqli_real_escape_string($conn, trim($_POST['address']));

    if (empty($firstname) || empty($lastname) || empty($email) || empty($phone) || empty($country_code)) {
        echo "All required fields must be filled.";
        exit;
    }

    // Checks if the updated contact details already exist
    $check_query = "SELECT * FROM contacts WHERE user_id = ? AND (email = ? OR (country_code = ? AND phone = ?)) AND id != ?";
    if ($stmt = $conn->prepare($check_query)) {
        $stmt->bind_param("isssi", $user_id, $email, $country_code, $phone, $id);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            echo "exists";
            $stmt->close();
            $conn->close();
            exit;
        }
        $stmt->close();
    } else {
        echo "Prepare failed: " . htmlspecialchars($conn->error);
        $conn->close();
        exit;
    }

    // Updates contact details
    $query = "UPDATE contacts SET firstname = ?, middlename = ?, lastname = ?, email = ?, country_code = ?, phone = ?, address = ? WHERE id = ? AND user_id = ?";
    if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param("ssssssssi", $firstname, $middlename, $lastname, $email, $country_code, $phone, $address, $id, $user_id);
        if ($stmt->execute()) {
            echo "success";
        } else {
            echo "error: " . htmlspecialchars($stmt->error);
        }
        $stmt->close();
    } else {
        echo "error: " . htmlspecialchars($conn->error);
    }

    $conn->close();
}
?>
